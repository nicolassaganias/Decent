/*
 * Calibration Process for pH Sensors
 *
 * The calibration process involves the following steps:
 *
 * 1. **Entering Calibration Mode:**
 *    - The user sends a command to enter calibration mode (e.g., "enterph1" or "enterph2").
 *    - This initializes the calibration procedure for the respective pH sensor.
 * 
 * 2. **Reading the pH Sensor Data:**
 *    - The pH voltage is read from the sensor using `analogRead()`.
 *    - This voltage is then converted to a corresponding pH value using the pH sensor's library functions.
 * 
 * 3. **Calibration Command:**
 *    - The user sends a command (e.g., "calph1" or "calph2") to calibrate the sensor.
 *    - The current temperature is checked; if valid, it is used for calibration. If not, a default temperature (25°C) is applied.
 *    - The sensor calibration function is called with the current pH voltage and temperature.
 * 
 * 4. **Exiting Calibration Mode:**
 *    - The user sends a command to exit calibration mode (e.g., "exitph1" or "exitph2").
 *    - The last recorded pH voltage and temperature are used to finalize the calibration.
 *    - A confirmation message is printed to indicate that the calibration has been completed.
 *
 * The calibration commands are handled in the `handlepHCommand()` function, which checks for user input and directs
 * it to the appropriate calibration functions for the specific pH sensor.
 */

#include "DFRobot_ESP_PH.h"
#include <EEPROM.h>

DFRobot_ESP_PH ph1;  // pH sensor 1
DFRobot_ESP_PH ph2;  // pH sensor 2

#define ESP_ADC_RANGE 4096.0       // the esp Analog Digital Conversion value
#define ESP_REF_VOLTAGE 3300       // the esp voltage supply value
#define PH_DEFAULT_TEMPERATURE 25  // default temperature

#define ENTER "ENTERPH"  // enter pH calibration mode
#define CAL "CALPH"      // send command to calibrate pH mode
#define EXIT "EXITPH"    //exit pH calibration mode

bool calibration_mode_enable = false;    // enable pH calibration mode
float pH1_temperature, pH2_temperature;  // temperature values for the both pH sensor
float return_ph_voltage;                 // return ph calculated voltage

void phInit() {
  EEPROM.begin(64);  // begin eeprom
  ph1.begin();       // initialize the pH sensor 1
  ph2.begin();       // initialize the pH sensor 2
}

// read pH 1 sensor data
float readpHSensor1() {
  float ph_voltage, ph_value;
  ph_voltage = analogRead(PH_SENSOR1_PIN) / ESP_ADC_RANGE * ESP_REF_VOLTAGE;
  ph_value = ph1.readPH(ph_voltage, PH_DEFAULT_TEMPERATURE);
  ph1.calibration(ph_voltage, PH_DEFAULT_TEMPERATURE);
  return ph_value;
}

// read pH 2 sensor data
float readpHSensor2() {
  float ph_voltage, ph_value;
  ph_voltage = analogRead(PH_SENSOR2_PIN) / ESP_ADC_RANGE * ESP_REF_VOLTAGE;
  ph_value = ph2.readPH(ph_voltage, PH_DEFAULT_TEMPERATURE);
  ph2.calibration(ph_voltage, PH_DEFAULT_TEMPERATURE);
  return ph_value;
}

void calibratepHSensor1(String calibration_data) {
  if (calibration_data == "enterph1") {
    ph1.calibration(3.2, 25.0, ENTER);
  } else if (calibration_data == "calph1") {
    // change the temperature value, if the current temperature is available
    if (temperature > 0) {
      pH1_temperature = temperature;
    } else {
      pH1_temperature = PH_DEFAULT_TEMPERATURE;
    }
    float ph_voltage;
    ph_voltage = analogRead(PH_SENSOR1_PIN) / ESP_ADC_RANGE * ESP_REF_VOLTAGE;
    ph1.calibration(ph_voltage, pH1_temperature, CAL);
    return_ph_voltage = ph_voltage;
  } else if (calibration_data == "exitph1") {
    ph1.calibration(return_ph_voltage, pH1_temperature, EXIT);
    Serial.println("Calibration completed!");
    calibration_mode_enable = false;
  }
}

void calibratepHSensor2(String calibration_data) {
  if (calibration_data == "enterph2") {
    ph2.calibration(3.2, 25.0, ENTER);
  } else if (calibration_data == "calph2") {
    // change the temperature value, if the current temperature is available
    if (temperature > 0) {
      pH2_temperature = temperature;
    } else {
      pH2_temperature = PH_DEFAULT_TEMPERATURE;
    }
    float ph_voltage;
    ph_voltage = analogRead(PH_SENSOR2_PIN) / ESP_ADC_RANGE * ESP_REF_VOLTAGE;
    ph2.calibration(ph_voltage, pH2_temperature, CAL);
    return_ph_voltage = ph_voltage;
  } else if (calibration_data == "exitph2") {
    ph2.calibration(return_ph_voltage, pH2_temperature, EXIT);
    Serial.println("Calibration completed!");
    calibration_mode_enable = false;
  }
}

void handlepHCommand() {
  if (Serial.available() > 0) {
    String serial_data = Serial.readStringUntil('\n');
    if (serial_data == "calibration") {
      Serial.println("Calibration mode started. Enter the calibration command...");
      calibration_mode_enable = true;
    }

    if (calibration_mode_enable) {
      if (serial_data == "enterph1" || serial_data == "calph1" || serial_data == "exitph1") {
        calibratepHSensor1(serial_data);
      } else {
        calibratepHSensor2(serial_data);
      }
    }
  }
}
