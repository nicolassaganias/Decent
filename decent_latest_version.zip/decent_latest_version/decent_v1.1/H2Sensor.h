int readHydrogen() {
  int read_adc = analogRead(H2_SENSOR_PIN);  // read sensor value
  int hydrogen_data = map(read_adc, 0, 4095, 0, 100);
  return hydrogen_data;
}